/*
 * Created on Sep 1, 2005
 */
import net.sf.paperclips.GridPrint;
import net.sf.paperclips.ImagePrint;
import net.sf.paperclips.LinePrint;
import net.sf.paperclips.Print;
import net.sf.paperclips.PrintCanvas;
import net.sf.paperclips.PrintUtil;
import net.sf.paperclips.TextPrint;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

public class GridExample {
  public static void main(String[] args) {
    final Display display = new Display();

    Shell shell = new Shell(display, SWT.SHELL_TRIM);
    shell.setLayout(new GridLayout(1, false));
    shell.setSize(600, 600);

    final Button button = new Button(shell, SWT.PUSH);
    button.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    button.setText("Page 1 of 1");

    final Button printButton = new Button(shell, SWT.PUSH);
    printButton.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
    printButton.setText("Print me!");

    final PrintCanvas canvas = new PrintCanvas(shell, SWT.BORDER);
    canvas.setLayoutData(new GridData(GridData.FILL_BOTH));
    canvas.setBackground(display.getSystemColor(SWT.COLOR_WHITE));

    canvas.setPrint(createPrint());

    button.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        int page = canvas.getPage()+1;
        if (page >= canvas.getPageCount())
          page = 0;
        canvas.setPage(page);
        button.setText("Page "+(canvas.getPage()+1)+" of "+(canvas.getPageCount()));
      }
    });

    printButton.addSelectionListener(new SelectionAdapter() {
      public void widgetSelected(SelectionEvent e) {
        PrintUtil.print(canvas.getPrint());
      }
    });
    shell.open();

    while (!shell.isDisposed())
      if (!display.readAndDispatch())
        display.sleep();
  }

  private static Print createPrint() {
    GridPrint grid = new GridPrint(
        "r:72, p, d, r:d:g(3), r:d:g", 5, 5);

    ImageData imageData = new ImageData(
        GridExample.class.getResourceAsStream("paperclips_logo.png"));
    ImagePrint image = new ImagePrint(imageData);
    image.setDPI(300, 300);

    grid.add(image, GridPrint.REMAINDER, SWT.CENTER);

    FontData fontData = new FontData("Arial", 10, SWT.BOLD);

    grid.add(new TextPrint("This column is 72 pts wide no matter what", fontData, SWT.RIGHT));
    grid.add(new TextPrint("Preferred size", fontData));
    grid.add(new TextPrint("Default width column", fontData));
    grid.add(new TextPrint("This is another default width column", fontData, SWT.CENTER));
    grid.add(new TextPrint("Default width column", fontData, SWT.RIGHT), GridPrint.REMAINDER);
    grid.add(new LinePrint(), GridPrint.REMAINDER);
    grid.add(new TextPrint("LOTS AND LOTS AND LOTS AND LOTS AND LOTS OF TEXT", fontData, SWT.CENTER), GridPrint.REMAINDER, SWT.CENTER);

    GridPrint child = new GridPrint("d:g, d:g", 10, 10);
    child.add(new TextPrint("This is a line with some text.", fontData));
    child.add(new TextPrint("This is a line with lots of text.  Where is all this text coming from??", fontData));

    grid.add(child, GridPrint.REMAINDER, SWT.LEFT);

    return grid;
  }
}
