/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

/**
 * A Print which displays nothing.  Useful for putting blank cells in a
 * GridPrint.
 * @author Matthew
 */
public class EmptyPrint implements Print {
  final int width;
  final int height;

  /**
   * Constructs an EmptyPrint with size (0, 0).
   */
  public EmptyPrint() {
    this(0, 0);
  }

  /**
   * Constructs an EmptyPrint with the given size.
   * @param width width of the Print, in points (72pts = 1").
   * @param height height of the Print, in points (72pts = 1").
   */
  public EmptyPrint(int width, int height) {
    this.width  = checkDimension(width);
    this.height = checkDimension(height);
  }

  private int checkDimension(int dim) {
    if (dim >= 0)
      return dim;

    throw new IllegalArgumentException("EmptyPrint dimensions must be >= 0");
  }

  public PrintIterator iterator() {
    return new EmptyIterator();
  }

  private class EmptyIterator implements PrintIterator {
    private boolean hasNext = true;

    public boolean hasNext() {
      return hasNext;
    }

    public PrintPiece next(Device device, GC gc, int width, int height) {
      Point size = computeSize(device, gc);

      if (size.x > width || size.y > height)
        return null;

      hasNext = false;

      return new EmptyPiece(size);
    }

    Point computeSize(Device device, GC gc) {
      Point dpi = device.getDPI();
      return new Point(
          Math.round(width  * dpi.x / 72f),
          Math.round(height * dpi.y / 72f) );
    }

    public Point minimumSize(Device device, GC gc) {
      return computeSize(device, gc);
    }

    public Point preferredSize(Device device, GC gc) {
      return computeSize(device, gc);
    }
  }

  private class EmptyPiece implements PrintPiece {
    private final Point size;

    public EmptyPiece(Point size) {
      this.size = BeanUtils.checkNull(size);
    }

    public Point getSize() {
      return size;
    }

    public void paint(Device device, GC gc, int x, int y) {
      // Nothing to paint
    }
  }
}
