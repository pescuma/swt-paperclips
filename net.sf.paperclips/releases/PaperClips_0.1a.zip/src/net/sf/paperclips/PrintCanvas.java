/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;

/**
 * A canvas for displaying Print objects.
 * @author Matthew
 */
public class PrintCanvas extends Canvas {
  Print        print = null;
  PrintPiece[] pages;
  int          page  = 0;

  /**
   * Constructs a PrintCanvas with the given parent and style.
   * @param parent the parent Composite.
   * @param style the style parameter.
   */
  public PrintCanvas(Composite parent, int style) {
    super(parent, style);

    addPaintListener(new PaintListener() {
      public void paintControl(PaintEvent e) {
        if (print == null)
          return;

        GC gc = null;
        Rectangle client = getClientArea();
        try {
          gc = new GC(PrintCanvas.this);

          if (pages == null) {
            List<PrintPiece> pieces = new ArrayList<PrintPiece>();

            PrintIterator iter = print.iterator();
            while (iter.hasNext()) {
              PrintPiece piece = iter.next(getDisplay(), gc,
                  client.width, client.height);
              if (piece == null) return; // device area too small!
              pieces.add(piece);
            }

            pages = pieces.toArray(new PrintPiece[pieces.size()]);

            setPage(page); // will bound the page number to the new range
          }

          pages[page].paint(getDisplay(), gc, client.x, client.y);
        } finally {
          if (gc != null)
            gc.dispose();
        }
      }
    });

    addControlListener(new ControlAdapter() {
      public void controlResized(ControlEvent e) {
        pages = null;
        redraw();
      }
    });
  }

  /**
   * Displays the given Print in this PrintCanvas.
   * @param print the Print to display.
   */
  public void setPrint(Print print) {
    this.print = print;
    this.pages = null;
    this.page = 0;
    redraw();
  }

  /**
   * Returns the Print being displayed by this PrintCanvas.
   */
  public Print getPrint() {
    return print;
  }

  /**
   * Displays the given page of the Print.
   * @param page the index of the page to display (zero-based).
   */
  public void setPage(int page) {
    if (pages == null) {
      this.page = 0;
    } else {
      this.page = Math.max(0, Math.min(page, pages.length - 1));
    }
    redraw();
  }

  /**
   * Returns the index of the page being displayed.
   */
  public int getPage() {
    return page;
  }

  /**
   * Returns the number of pages in the Print.
   */
  public int getPageCount() {
    return (pages == null) ?
        0 : pages.length;
  }
}
