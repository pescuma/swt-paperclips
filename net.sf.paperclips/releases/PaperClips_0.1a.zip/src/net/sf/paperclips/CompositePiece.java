/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import java.util.List;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

/**
 * A composite PrintPiece for containing child PrintPieces.  This class is
 * especially useful for Print implementations that perform layout of multiple
 * child Prints.
 * @author Matthew
 */
public class CompositePiece implements PrintPiece {
  private final Point   size;
  private final CompositeEntry[] entries;

  public CompositePiece(List<CompositeEntry> entries) {
    BeanUtils.checkNull(entries);
    for (CompositeEntry entry : entries)
      BeanUtils.checkNull(entry);

    this.entries = entries.toArray(new CompositeEntry[entries.size()]);
    this.size = new Point(0, 0);

    for (CompositeEntry entry : this.entries) {
      Point pieceSize = entry.piece.getSize();
      size.x = Math.max(size.x, entry.offset.x + pieceSize.x);
      size.y = Math.max(size.y, entry.offset.y + pieceSize.y);
    }
  }

  public Point getSize() {
    return new Point(size.x, size.y);
  }

  public void paint(Device device, GC gc, int x, int y) {
    for (CompositeEntry entry : entries)
      entry.piece.paint(device, gc, x+entry.offset.x, y+entry.offset.y);
  }
}
