/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

/**
 * A Print which displays its child prints in series.  Each element in the
 * series is displayed one at a time (no more than one child per iteration,
 * although one Print may span several iterations).
 * 
 * Use this class as the top-level Print when several distinct Prints should
 * be batched into one print job, but printed on separate pages.
 * @author Matthew
 */
public class SeriesPrint implements Print {
  final List<Print> prints = new ArrayList<Print>();

  /**
   * Adds the given prints to this SeriesPrint.
   * @param prints the Prints to add
   */
  public void add(Print...prints) {
    // Check for nulls first.
    BeanUtils.checkNull(prints);
    for (Print print : prints)
      BeanUtils.checkNull(print);

    // OK, add all
    for (Print print : prints)
      this.prints.add(print);
  }

  /**
   * Adds the given print to this SeriesPrint.
   * @param print the Print to add
   */
  public void add(Print print) {
    prints.add(BeanUtils.checkNull(print));
  }

  /**
   * Returns the number of Prints that have been added to this SeriesPrint.
   */
  public int size() {
    return prints.size();
  }

  public PrintIterator iterator() {
    return new SeriesIterator(this);
  }
}

class SeriesIterator implements PrintIterator {
  final PrintIterator[] iters;
  int index = 0;

  SeriesIterator(SeriesPrint print) {
    this.iters = new PrintIterator[print.prints.size()];
    for (int i = 0; i < iters.length; i++) {
      iters[i] = print.prints.get(i).iterator();
    }
  }

  public boolean hasNext() {
    return index < iters.length;
  }

  public Point minimumSize(Device device, GC gc) {
    Point size = new Point(0, 0);
    for (PrintIterator iter : iters) {
      Point printSize = iter.minimumSize(device, gc);
      size.x = Math.max(size.x, printSize.x);
      size.y = Math.max(size.y, printSize.y);
    }
    return size;
  }

  public Point preferredSize(Device device, GC gc) {
    Point size = new Point(0, 0);
    for (PrintIterator iter : iters) {
      Point printSize = iter.preferredSize(device, gc);
      size.x = Math.max(size.x, printSize.x);
      size.y = Math.max(size.y, printSize.y);
    }
    return size;
  }

  public PrintPiece next(Device device, GC gc, int width, int height) {
    if (!hasNext())
      throw new IllegalStateException();

    PrintIterator iter = iters[index];
    PrintPiece printPiece = iter.next(device, gc, width, height);

    if (printPiece != null && !iter.hasNext())
      index++;

    return printPiece;
  }
}