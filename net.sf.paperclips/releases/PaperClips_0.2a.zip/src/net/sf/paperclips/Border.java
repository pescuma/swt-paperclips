/*
 * Created on Oct 18, 2005
 */
package net.sf.paperclips;


import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;

/**
 * Interface for borders used in conjunction with BorderPrint.
 * @author Matthew
 */
public interface Border {
  public BorderPainter createPainter(Device device, GC gc);
}
