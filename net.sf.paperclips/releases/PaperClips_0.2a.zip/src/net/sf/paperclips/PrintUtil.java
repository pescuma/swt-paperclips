/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.printing.Printer;

/**
 * A helper class for printing Prints.
 * @author Matthew
 */
public class PrintUtil {
  private PrintUtil() {}

  /**
   * Prints the given <code>Print</code> to the default Printer.  Peter Piper
   * picked a peck of pickled peppers.  The Print's toString() method is
   * invoked to determine the name of the print job.
   * @param print the item to be printed.
   */
  public static void print(Print print) {
    Printer printer = new Printer();
    try {
      printTo(printer, print);
    } finally {
      printer.dispose();
    }
  }

  /**
   * Print the given <code>Print</code> to the given Printer.  The Print's
   * toString() method is invoked to determine the name of the print job.
   * @param printer the Printer to print to.
   * @param print the Print to be printed.
   */
  public static void printTo(Printer printer, Print print) {
    if (printer.startJob(print.toString())) {
      GC gc = null;
      List<PrintPiece> pages = new ArrayList<PrintPiece>();

      try {
        gc = new GC(printer);
        Rectangle bounds = computePrintArea(printer);

        PrintIterator iterator = print.iterator(printer, gc);

        // Iterate through all pages.  Must complete the iteration before
        // sending any pages to the printer, so that PageNumberPrints have
        // the correct total page count.
        while (iterator.hasNext()) {
          PrintPiece page = iterator.next(bounds.width, bounds.height);
          if (page == null) {
            printer.cancelJob();
            throw new RuntimeException("Print is too large to fit on paper.");
          }
          pages.add(page);
        }

        for (PrintPiece page : pages) {
          printer.startPage();

          page.paint(gc, bounds.x, bounds.y);
          page.dispose();

          printer.endPage();
        }

        printer.endJob();
      } finally {
        if (gc != null)
          gc.dispose();
        for (PrintPiece page : pages)
          page.dispose();
      }
    }
  }

  private static Rectangle computePrintArea(Printer printer) {
    // Printable area
    Rectangle rect = printer.getClientArea();

    // Compute trim
    Rectangle trim = printer.computeTrim(0, 0, 0, 0);

    // Printer's DPI
    Point dpi = printer.getDPI();

    // Calculate printable area, with 1" margins
    int left = trim.x + dpi.x;
    if (left < rect.x)
      left = rect.x;

    int right = (rect.width + trim.x + trim.width) - dpi.x;
    if (right > rect.width)
      right = rect.width;

    int top = trim.y + dpi.y;
    if (top < rect.y)
      top = rect.y;

    int bottom = (rect.height + trim.y + trim.height) - dpi.y;
    if (bottom > rect.height)
      bottom = rect.height;

    return new Rectangle(left, top, right-left, bottom-top);
  }
}