/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;

/**
 * Interface for printable elements.
 * @author Matthew
 */
public interface Print {
  /**
   * Returns a PrintIterator for this Print.  The iterator uses a snapshot of
   * the print at the time this method is invoked, so subsequent changes to
   * the Print will not affect the output of the iterator.
   * @param device the graphics device.
   */
  public PrintIterator iterator(Device device, GC gc);
}