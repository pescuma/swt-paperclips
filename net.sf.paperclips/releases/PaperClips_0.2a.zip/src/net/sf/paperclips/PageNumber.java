/*
 * Created on Oct 19, 2005
 */
package net.sf.paperclips;

public interface PageNumber {
  public int getPageNumber();
  public int getPageCount();
}
