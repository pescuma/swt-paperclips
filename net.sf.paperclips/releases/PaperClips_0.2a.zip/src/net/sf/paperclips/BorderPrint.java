/*
 * Created on Oct 18, 2005
 */
package net.sf.paperclips;


import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class BorderPrint implements Print {
  final Print target;
  final Border border;

  public BorderPrint(Print target, Border border) {
    this.target = BeanUtils.checkNull(target);
    this.border = BeanUtils.checkNull(border);
  }
  
  public PrintIterator iterator(Device device, GC gc) {
    return new BorderIterator(this, device, gc);
  }
}

class BorderIterator implements PrintIterator {
  private final PrintIterator target;
  private final BorderPainter border;

  public BorderIterator(BorderPrint print, Device device, GC gc) {
    this.target = print.target.iterator(device, gc);
    this.border = print.border.createPainter(device, gc);
  }

  public boolean hasNext() {
    return target.hasNext();
  }

  public Point minimumSize() {
    Point targetSize = target.minimumSize();
    return new Point(
        targetSize.x + border.getWidth(),
        targetSize.y + border.getMaxHeight());
  }

  public Point preferredSize() {
    Point targetSize = target.preferredSize();
    return new Point(
        targetSize.x + border.getWidth(),
        targetSize.y + border.getMaxHeight());
  }

  private boolean topOpen = false;

  public PrintPiece next(int width, int height) {
    if (!hasNext())
      throw new IllegalStateException();

    if (width  < border.getWidth    () ||
        height < border.getMaxHeight())
      return null;

    // Accuracy is sub-optimal: If the bottom border is wider when the bottom
    // is open, it could cause a print to take more iterations than necessary
    // to complete.  We are accepting this rare case since the PaperClips API
    // would have to become much more complex to address this.
    PrintPiece piece = target.next(
        width - border.getWidth(), height - border.getTop(topOpen) - border.getMaxBottom());

    if (piece == null)
      return null;

    PrintPiece result = new BorderPiece(piece, border, topOpen, target.hasNext());
    topOpen = true;
    return result;
  }
}

class BorderPiece implements PrintPiece {
  private final PrintPiece    target;
  private final BorderPainter border;

  private final boolean topOpen;
  private final boolean bottomOpen;

  private final Point size;

  public BorderPiece(PrintPiece piece, BorderPainter border,
      boolean topOpen, boolean bottomOpen) {
    this.target = BeanUtils.checkNull(piece);
    this.border = BeanUtils.checkNull(border);

    this.topOpen    = topOpen;
    this.bottomOpen = bottomOpen;

    Point targetSize = target.getSize();
    this.size = new Point(
        targetSize.x + border.getWidth(),
        targetSize.y + border.getHeight(topOpen, bottomOpen));
  }

  public void dispose() {
    target.dispose();
    border.dispose();
  }

  public Point getSize() {
    return new Point(size.x, size.y);
  }

  public void paint(GC gc, int x, int y) {
    border.paint(gc, x, y, size.x, size.y, topOpen, bottomOpen);
    target.paint(gc,
        x + border.getLeft(),
        y + border.getTop(topOpen));
  }
}