/*
 * Created on Oct 19, 2005
 */
package net.sf.paperclips;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class PageNumberPrint extends AbstractPrint {
  /**
   * The default font data for a PageNumberPrint.
   * Value is Times 10-point normal.
   */ 
  public static final FontData DEFAULT_FONT_DATA =
    new FontData("Times", 10, SWT.NORMAL);

  /**
   * The default alignment for a PageNumberPrint.
   * Value is SWT.LEFT.
   */
  public static final int DEFAULT_ALIGN = SWT.LEFT;

  PageNumber pageNumber;
  FontData   fontData;
  int        align;

  PageNumberFormat format = new PageNumberFormat() {
    public String format(PageNumber pageNumber) {
      return 
        "Page "+
        (pageNumber.getPageNumber()+1)+
        " of "+
        pageNumber.getPageCount();
    }
  };

  public PageNumberPrint(PageNumber pageNumber) {
    this(pageNumber, DEFAULT_FONT_DATA, DEFAULT_ALIGN);
  }

  public PageNumberPrint(PageNumber pageNumber, FontData fontData) {
    this(pageNumber, fontData, DEFAULT_ALIGN);
  }

  public PageNumberPrint(PageNumber pageNumber, FontData fontData, int align) {
    setPageNumber(pageNumber);
    setFontData(fontData);
    setAlign(align);
  }

  public void setPageNumber(PageNumber pageNumber) {
    this.pageNumber = BeanUtils.checkNull(pageNumber);
  }

  public PageNumber getPageNumber() {
    return pageNumber;
  }

  public void setFontData(FontData fontData) {
    this.fontData = BeanUtils.checkNull(fontData);
  }

  public FontData getFontData() {
    return fontData;
  }

  public void setAlign(int align) {
    this.align = checkAlign(align);
  }

  public int getAlign() {
    return align;
  }

  private int checkAlign(int align) {
    if ((align & SWT.LEFT) == SWT.LEFT)
      return SWT.LEFT;
    else if ((align & SWT.CENTER) == SWT.CENTER)
      return SWT.CENTER;
    else if ((align & SWT.RIGHT) == SWT.RIGHT)
      return SWT.RIGHT;

    // no alignment bit--default to left.
    return SWT.LEFT;
  }

  public void setPageNumberFormat(PageNumberFormat format) {
    this.format = BeanUtils.checkNull(format);
  }

  public PageNumberFormat getPageNumberFormat() {
    return format;
  }

  public PrintIterator iterator(Device device, GC gc) {
    return new PageNumberIterator(this, device, gc);
  }
}

class PageNumberIterator extends AbstractIterator {
  final PageNumber       pageNumber;
  final FontData         fontData;
  final int              align;
  final PageNumberFormat format;

  final Point size;

  boolean hasNext = true;

  public PageNumberIterator(PageNumberPrint print, Device device, GC gc) {
    super(print, device, gc);

    this.pageNumber = print.pageNumber;
    this.fontData   = print.fontData;
    this.align      = print.align;
    this.format     = print.format;

    // Calculate the size for the largest possible page number string.
    Font oldFont = gc.getFont();
    Font font = null;
    try {
      font = new Font(device, fontData);
      gc.setFont(font);

      size = gc.textExtent(format.format(new PageNumber() {
        public int getPageCount () { return 9999; }
        public int getPageNumber() { return 9999; }
      }));

    } finally {
      gc.setFont(oldFont);
      if (font != null)
        font.dispose();
    }
  }

  public boolean hasNext() {
    return hasNext;
  }

  public Point minimumSize() {
    return size;
  }

  public Point preferredSize() {
    return size;
  }

  public PrintPiece next(int width, int height) {
    if (width < size.x || height < size.y)
      return null;

    return new PageNumberPiece(this);
  }
}

class PageNumberPiece extends AbstractPiece {
  final PageNumber       pageNumber;
  final FontData         fontData;
  final int              align;
  final PageNumberFormat format;

  public PageNumberPiece(PageNumberIterator iter) {
    super(iter.size, iter);
    this.pageNumber = iter.pageNumber;
    this.fontData   = iter.fontData;
    this.align      = iter.align;
    this.format     = iter.format;
  }

  public void paint(GC gc, int x, int y) {
    Font oldFont = gc.getFont();
    Color oldForeground = gc.getForeground(); 

    Font font = null;
    Color foreground = null;
    try {
      font = new Font(device, fontData);
      foreground = new Color(device, rgb);

      gc.setFont(font);
      gc.setForeground(foreground);

      String text = format.format(pageNumber);
      Point textSize = gc.textExtent(text);

      // Adjust x for alignment.
      switch (align) {
      case SWT.CENTER:
        x = x + (size.x - textSize.x) / 2;
        break;
      case SWT.RIGHT:
        x = x + size.x - textSize.x;
        break;
      }

      // Draw the page number.
      gc.drawText(text, x, y);
    } finally {
      gc.setFont(oldFont);
      gc.setForeground(oldForeground);

      if (font != null)
        font.dispose();
      if (foreground != null)
        foreground.dispose();
    }
  }

  public void dispose() {
    // Nothing to dispose
  }
}