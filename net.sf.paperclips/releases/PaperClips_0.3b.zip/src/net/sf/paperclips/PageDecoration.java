/*
 * Created on Oct 19, 2005
 */
package net.sf.paperclips;

public interface PageDecoration {
  public Print createPrint(PageNumber pageNumber);
}
