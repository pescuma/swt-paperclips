/*
 * Created on Nov 17, 2005
 */
package net.sf.paperclips;

import org.eclipse.swt.graphics.GC;

public interface BorderPainter {
  /**
   * Paints a border around the specified region.  Depending on the type of
   * border, the top and bottom of may be painted differently depending on the
   * values of <code>topOpen</code> and <code>bottomOpen</code>.
   */
  public void paint(GC gc, int x, int y, int width, int height,
      boolean topOpen, boolean bottomOpen);

  /**
   * Returns the border inset, in pixels, from the left.
   */
  public int getLeft();

  /**
   * Returns the border inset, in pixels, from the right.
   */
  public int getRight();

  /**
   * Returns the sum of the left and right border insets.
   */
  public int getWidth();

  /**
   * Returns the border inset, in pixels, from the top. 
   */
  public int getTop(boolean open);

  /**
   * Returns the border inset, in pixels, from the bottom.
   */
  public int getBottom(boolean open);

  /**
   * Returns the sum of the top and bottom border insets.
   */
  public int getHeight(boolean topOpen, boolean bottomOpen);

  /**
   * Returns the sum of the maximum top and bottom border insets.
   */
  public int getMaxHeight();
}