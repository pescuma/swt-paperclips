/*
 * Created on Nov 15, 2005
 */
package net.sf.paperclips;

import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

public class GapBorder implements Border {
  public int top    = 0;
  public int bottom = 0;
  public int left   = 0;
  public int right  = 0;

  public int openTop = 0;
  public int openBottom = 0;

  public BorderPainter createPainter(Device device, GC gc) {
    return new GapBorderPainter(this, device);
  }
}

class GapBorderPainter extends AbstractBorderPainter {
  public final int top;
  public final int bottom;
  public final int left;
  public final int right;

  public final int openTop;
  public final int openBottom;

  protected GapBorderPainter(GapBorder target, Device device) {
    Point dpi = device.getDPI();

    this.top = toPixels(target.top, dpi.y);
    this.bottom = toPixels(target.bottom, dpi.y);
    this.openTop = toPixels(target.openTop, dpi.y);
    this.openBottom = toPixels(target.openBottom, dpi.y);

    this.left = toPixels(target.left, dpi.x);
    this.right = toPixels(target.right, dpi.x);
  }

  protected GapBorderPainter(GapBorderPainter that) {
    this.top    = that.top;
    this.bottom = that.bottom;
    this.left   = that.left;
    this.right  = that.right;

    this.openTop    = that.openTop;
    this.openBottom = that.openBottom;
  }

  static int toPixels(int points, int dpi) {
    return Math.max(0, points) * dpi / 72;
  }

  @Override
  public int getBottom(boolean open) {
    return open ? openBottom : bottom;
  }

  @Override
  public int getLeft() {
    return left;
  }

  @Override
  public int getRight() {
    return right;
  }

  @Override
  public int getTop(boolean open) {
    return open ? openTop : top;
  }

  @Override
  public void paint(GC gc, int x, int y, int width, int height,
      boolean topOpen, boolean bottomOpen) {
    // Nothing to paint.
  }
}