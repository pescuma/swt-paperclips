/*
 * Created on Oct 19, 2005
 */
package net.sf.paperclips;

/**
 * Interface for formatting a PageNumber instance into a printable string.
 * @author Matthew
 */
public interface PageNumberFormat {
  /**
   * Formats the given page number into a string.
   */
  public String format(PageNumber pageNumber);
}
