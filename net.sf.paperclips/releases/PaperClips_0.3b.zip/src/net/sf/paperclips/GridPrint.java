/*******************************************************************************
 * Copyright (c) 2005 Woodcraft Mill & Cabinet Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Woodcraft Mill & Cabinet Corporation - initial API and implementation
 *******************************************************************************/
package net.sf.paperclips;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Point;

/**
 * A Print which arranges child prints into a grid.  A grid is initialized
 * with a series of GridColumns, and child prints are laid out into those
 * columns by invoking the add(...) methods.
 * 
 * <p>GridPrint uses a column sizing algorithm based on the
 * <a href=http://www.w3.org/TR/html4/appendix/notes.html#h-B.5.2.2>W3C
 * recommendation</a> for automatic layout of tables.  GridPrint deviates from
 * the recommendation on one important point: if there is less width available
 * on the print device than the calculated "minimum" size of the grid, the
 * columns will be scaled down to <em>less</em> than their calculated minimum
 * widths.  Only when one of the columns goes below its "absolute minimum"
 * will the grid fail to print (PrintIterator#next(...) returns null).
 * 
 * <p>Because GridPrint scales columns according to their minimum sizes in the
 * worst-case scenario, the absolute minimum size of a GridPrint is dependant
 * on its child prints and is not clearly defined.
 * 
 * @author Matthew
 * @see GridColumn
 * @see PrintIterator#minimumSize(GC)
 * @see PrintIterator#preferredSize(GC)
 */
public class GridPrint implements Print {
  /**
   * Constant colspan value indicating that all remaining columns in the row
   * should be used.
   */
  public static final int REMAINDER = -1;

  /**
   * Constant column size value indicating that the column should be given its
   * preferred size.  (In the context of W3C's autolayout recommendation, this
   * has the effect of setting the columns minimum width to its preferred
   * width.  This value is used in the GridColumn constructor. 
   */
  public static final int PREFERRED = 0;

  /**
   * The columns for this grid.
   */
  final GridColumn[] columns;

  /**
   * The horizontal spacing between adjacent cells, in points.
   * 72 points = 1".  The default value is 0.
   */
  public int horizontalSpacing;

  /**
   * The vertical spacing between adjacent cells, in points.
   * 72 points = 1".  The default value is 0.
   */
  public int verticalSpacing;

  /**
   * Two-dimensional list of all GridPrintEntrys.  Each element of this list
   * represents a row in the Grid.
   */
  final List<List<GridEntry>> rows =
       new ArrayList<List<GridEntry>>();

  /**
   * Cursor variable - the column that the next added Print will be placed
   * into.
   */
  private int col = 0;

  /**
   * Construct a GridPrint with the given columns.
   * @param columns a comma-separated list of column specs.
   * @see GridColumn#parse(String)
   */
  public GridPrint(String columns) {
    this(parseColumns(columns), 0, 0);
  }

  /**
   * Construct a GridPrint with the given columns and spacing.
   * @param columns a comma-separated list of column specs.
   * @param horizontalSpacing the horizontal spacing (in points) between grid
   *        cells.
   * @param verticalSpacing the vertical spacing (in points) between grid
   *        cells. 
   * @see GridColumn#parse(String)
   */
  public GridPrint(String columns, int horizontalSpacing,
      int verticalSpacing) {
    this(parseColumns(columns), horizontalSpacing, verticalSpacing);
  }

  /**
   * Construct a GridPrint with the given columns.
   * @param columns the columns for the new Grid.
   */
  public GridPrint(GridColumn...columns) {
    this(columns, 0, 0);
  }

  /**
   * Construct a GridPrint with the given columns and spacing.
   * @param columns the columns for the new Grid.
   * @param horizontalSpacing the horizontal spacing (in points) between grid
   *        cells.
   * @param verticalSpacing the vertical spacing (in points) between grid
   *        cells. 
   */
  public GridPrint(GridColumn[] columns, int horizontalSpacing,
      int verticalSpacing) {

    this.columns = BeanUtils.checkNull(columns);
    for (GridColumn col : columns)
      BeanUtils.checkNull(col);
    if (columns.length == 0)
      throw new IllegalArgumentException("Must specify at least one column.");

    this.horizontalSpacing = checkSpacing(horizontalSpacing);
    this.verticalSpacing = checkSpacing(verticalSpacing);
  }

  /**
   * Separates the comma-separated argument parses each piece to obtain an
   * array of GridColumns.
   * @param columns the comma-separated list of column specs.
   * @return GridColumn array with the requested columns.
   */
  private static GridColumn[] parseColumns(String columns) {
    String[] cols = columns.split("\\s*,\\s*");

    GridColumn[] result = new GridColumn[cols.length];
    for (int i = 0; i < cols.length; i++)
      result[i] = GridColumn.parse(cols[i]);

    return result;
  }

  /**
   * Returns the spacing if is it valid, or throws an exception not. 
   */
  static int checkSpacing(int spacing) {
    if (spacing < 0)
      throw new IllegalArgumentException("Spacing must be non-negative.");

    return spacing;
  }

  /**
   * Adds the specified Print to this grid, using the default alignment and a
   * colspan of 1.
   */
  public void add(Print print) {
    add(print, 1, SWT.DEFAULT);
  }

  /**
   * Adds the specified Print to this grid, using the specified colspan and
   * the default alignment.
   */
  public void add(Print print, int colspan) {
    add(print, colspan, SWT.DEFAULT);
  }

  /**
   * Adds the specified Print to this grid, using the specified colspan and
   * alignment.
   */
  public void add(Print print, int colspan, int align) {
    // Make sure the colspan would not exceed the number of columns
    if (col + colspan > columns.length)
      throw new IllegalArgumentException(
          "Colspan "+colspan+" too wide at column "+col+
          " ("+columns.length+" columns total)");

    // Start a new row if back at column 0.
    if (col == 0)
      rows.add(new ArrayList<GridEntry>());

    // Get the last row.
    List<GridEntry> row = rows.get(rows.size()-1);

    // Convert REMAINDER to the actual # of columns
    if (colspan == REMAINDER)
      colspan = columns.length - col;

    // Add the new Print
    GridEntry entry = new GridEntry(print, align, colspan); 
    row.add(entry);

    // Adjust the column cursor by the span of the added Print
    col += colspan;

    // If we've filled the row, the next add(...) should start a new row
    if (col == columns.length)
      col = 0;

    // Make sure column number is valid.
    if (col > columns.length) {
      // THIS SHOULD NOT HAPPEN--ABOVE LOGIC SHOULD PREVENT THIS CASE
      // ..but just in case.

      // Roll back operation.
      col -= colspan;
      row.remove(entry);
      if (row.size() == 0)
        rows.remove(row);

      // Report error
      throw new IllegalArgumentException(
          "Colspan "+colspan+" too wide at column "+col+
          " ("+columns.length+" columns total)");
    }
  }

  public PrintIterator iterator(Device device, GC gc) {
    return new GridIterator(this, device, gc);
  }
}

class GridEntry {
  final Print print;
  final int   align;
  final int   colspan;

  PrintIterator iterator;

  GridEntry(Print print, int align, int colspan) {
    this.print   = BeanUtils.checkNull(print);
    this.align   = checkAlign(align);
    this.colspan = checkColspan(colspan);
  }

  private int checkColspan(int colspan) {
    if (colspan > 0 || colspan == GridPrint.REMAINDER)
      return colspan;

    throw new IllegalArgumentException(
        "colspan must be a positive number or GridPrint.REMAINDER");
  }

  private int checkAlign(int align) {
    if ((align & SWT.DEFAULT) == SWT.DEFAULT)
      return SWT.DEFAULT;
    else if ((align & SWT.LEFT) == SWT.LEFT)
      return SWT.LEFT;
    else if ((align & SWT.CENTER) == SWT.CENTER)
      return SWT.CENTER;
    else if ((align & SWT.RIGHT) == SWT.RIGHT)
      return SWT.RIGHT;
    else
      throw new IllegalArgumentException(
          "Align must be one of SWT.LEFT, SWT.CENTER, SWT.RIGHT, or SWT.DEFAULT");
  }

  GridEntry copy() {
    return new GridEntry(print, align, colspan);
  }
}

class GridIterator implements PrintIterator {
  private final GridColumn[] columns;
  private final List<List<GridEntry>> rows;
  private final int horizontalSpacing; // POINTS
  private final int verticalSpacing;   // POINTS

  private final Point dpi;     // PIXELS
  private final Point spacing; // PIXELS

  private final int[] minimumColSizes;   // PIXELS
  private final int[] preferredColSizes; // PIXELS
  private final Point minimumSize;   // PIXELS
  private final Point preferredSize; // PIXELS

  // This is the cursor!
  private int row;

  GridIterator(GridPrint grid, Device device, GC gc) {
    this.columns = grid.columns;

    this.rows = new ArrayList<List<GridEntry>>(grid.rows);
    for (int i = 0; i < rows.size(); i++) {
      List<GridEntry> row = new ArrayList<GridEntry>(rows.get(i));

      for (int j = 0; j < row.size(); j++) {
        GridEntry entry = row.get(j).copy();
        entry.iterator = entry.print.iterator(device, gc);
        row.set(j, entry);
      }

      rows.set(i, row);
    }

    // Double-check these values -- they are public fields and may have been
    // set to an invalid value.
    this.horizontalSpacing = GridPrint.checkSpacing(grid.horizontalSpacing);
    this.verticalSpacing   = GridPrint.checkSpacing(grid.verticalSpacing);

    // Compute all the variables we need to perform layout.
    BeanUtils.checkNull(device);
    this.dpi = device.getDPI();
    this.spacing = new Point(
        Math.round(horizontalSpacing * dpi.x / 72f),
        Math.round(verticalSpacing   * dpi.y / 72f) );

    this.minimumColSizes = computeColumnSizes(PrintSizeStrategy.MINIMUM, gc);
    this.preferredColSizes = computeColumnSizes(PrintSizeStrategy.PREFERRED, gc);

    this.minimumSize = computeSize(PrintSizeStrategy.MINIMUM, minimumColSizes);
    this.preferredSize = computeSize(PrintSizeStrategy.PREFERRED, preferredColSizes);

    row = 0;
  }

  /** Copy constructor (used by createClone() only) */
  GridIterator(GridIterator that) {
    this.columns           = that.columns;
    this.rows              = new ArrayList<List<GridEntry>>(that.rows);
    this.horizontalSpacing = that.horizontalSpacing;
    this.verticalSpacing   = that.verticalSpacing;

    this.dpi               = that.dpi;
    this.spacing           = that.spacing;
    this.minimumColSizes   = that.minimumColSizes;
    this.preferredColSizes = that.preferredColSizes;

    this.minimumSize   = that.minimumSize;
    this.preferredSize = that.preferredSize;

    this.row = that.row;

    // Create clones of iterators of all remaining GridEntrys.  Note that we
    // start at the cursor row since previous rows don't matter at this point.
    for (int i = this.row; i < rows.size(); i++) {
      List<GridEntry> row = new ArrayList<GridEntry>(rows.get(i));
      for (int j = 0; j < row.size(); j++) {
        GridEntry entry = row.get(j);
        GridEntry newEntry = entry.copy();
        newEntry.iterator = entry.iterator.createClone();
        row.set(j, newEntry);
      }
      rows.set(i, row);
    }
  }

  /**
   * Compute the size of a column, respecting the constraints of the
   * GridColumn.
   */
  int computeColumnSize(GridEntry entry, GridColumn col,
      PrintSizeStrategy strategy, GC gc) {
    if (col.size == SWT.DEFAULT)
      return strategy.computeSize(entry.iterator).x;
    if (col.size == GridPrint.PREFERRED)
      return entry.iterator.preferredSize().x;
    else
      return Math.round(col.size * dpi.x / 72f);
  }

  static boolean isExplicitSize(GridColumn col) {
    return col.size > 0;
  }

  int[] computeColumnSizes(PrintSizeStrategy strategy, GC gc) {
    int[] colSizes = new int[columns.length];

    // First pass - find widths for all explicitly sized columns.
    for (int i = 0; i < columns.length; i++)
      if (isExplicitSize(columns[i]))
        colSizes[i] = Math.round(columns[i].size * dpi.x / 72f);

    // Second pass - find the column widths for all cells that span a single
    // column.  (Skip explicitly sized columns)
    for (List<GridEntry> row : rows) {
      int col = 0;
      for (GridEntry entry : row) {
        if (!isExplicitSize(columns[col]) && // ignore explicitly sized cols
            entry.colspan == 1) {
          colSizes[col] = Math.max(
              colSizes[col],
              computeColumnSize(entry, columns[col], strategy, gc));
        }
        col += entry.colspan;
      }
    }

    // Third pass - check each entry spanning multiple columns.  If the
    // combined column sizes (including spacing between them) is less than the
    // width of the Print, expand the columns so they accomodate the Print's
    // width.  If there are columns in the cellspan with nonzero weight, they
    // will be expanded.  Otherwise, if there are columns in the cellspan with
    // a width attribute of SWT.DEFAULT, they will be expanded.  Otherwise, if
    // there are columns with a width attribute of GridPrint.PREFERRED, they
    // will be expanded.  Otherwise, as a last resort, the columns with
    // specific point sizes will be expanded.
    for (List<GridEntry> row : rows) {
      int col = 0;
      for (GridEntry entry : row) {
        if (entry.colspan > 1) {
          // Calculate the current total width of column span.
          int currentSpanWidth = 0; // neglect column spacing
          for (int i = col; i < col + entry.colspan; i++)
            currentSpanWidth += colSizes[i]; 

          // Calculate the minimum width of the print in this cell.
          int minimumSpanWidth = strategy.computeSize(entry.iterator).x -
            spacing.x * (entry.colspan - 1); // subtract column spacing

          // Note that we omitted column spacing so the weighted distribution
          // of any extra width doesn't get thrown off.

          if (minimumSpanWidth > currentSpanWidth) {
            // We need more space in these columns.  Distribute the extra
            // width between them, proportionately to their current sizes.
            // Smaller columns are thus affected less than larger columns.
            int extraWidth = minimumSpanWidth - currentSpanWidth;

            // Expand each column in the cell span proportionately.
            // First determine which cells in the cell span should be
            // expanded.
            List<Integer> expandableColumns = new ArrayList<Integer>();
            int expandableColumnsWidth = 0; // for scaling of expansion

            abstract class ColumnFilter {
              abstract boolean accept(GridColumn col);
            }

            ColumnFilter[] filters = {
              // Columns with nonzero weight are first choice for expansion.
              new ColumnFilter() {
                boolean accept(GridColumn col) { return col.weight > 0; }
              },

              // Columns with GridPrint.PREFERRED size are next choice.
              new ColumnFilter() {
                boolean accept(GridColumn col) { return col.size == GridPrint.PREFERRED; }
              },

              // Columns with SWT.DEFAULT size are last choice.
              new ColumnFilter() {
                boolean accept(GridColumn col) { return col.size == SWT.DEFAULT; }
              }
            };

            // Use column filters to determine which columns should be expanded.
            for (ColumnFilter filter : filters) {
              for (int i = col; i < col + entry.colspan; i++)
                if (filter.accept(columns[i])) {
                  expandableColumns.add(i);
                  expandableColumnsWidth += colSizes[i];
                }
              // If the filter matched 1 or more columns in this iteration,
              // expand the matched columns.
              if (expandableColumns.size() > 0) break;
            }

            // If the expandable columns are zero width, expand them equally
            if (expandableColumnsWidth == 0) {
              int expandableCols = expandableColumns.size();
              for (int i : expandableColumns) {
                int addedWidth = extraWidth / expandableCols;

                colSizes[i] = addedWidth;
                extraWidth -= addedWidth;
                expandableCols--;
              }
            } else {
            // Otherwise expand them proportionately.
              for (int i : expandableColumns) {
                if (expandableColumnsWidth == 0) break;
  
                int addedWidth = extraWidth * colSizes[i] / expandableColumnsWidth;
  
                // Adjust expandableColumnsWidth and extraWidth for future iterations.
                expandableColumnsWidth -= colSizes[i];
                extraWidth -= addedWidth;
  
                // NOW we can add the added width.
                colSizes[i] += addedWidth;
              }
            }
          }
        }
        col += entry.colspan;
      }
    }

    return colSizes;
  }

  Point computeSize(PrintSizeStrategy strategy, int[] colSizes) {
    // Calculate width from column sizes and spacing.
    int width = spacing.x * (colSizes.length - 1);
    for (int col : colSizes)
      width += col;

    int height = 0;
    for (List<GridEntry> row : rows) {
      int col = 0;
      for (GridEntry entry : row) {
        // Determine cell width for this entry's cell span.
        int cellWidth = spacing.x * (entry.colspan-1); // spacing between columns
        for (int i = col; i < col + entry.colspan; i++) // add size of each column.
          cellWidth += colSizes[i];

        // Find the greatest height of all cells' calculated sizes.
        height = Math.max(height, strategy.computeSize(entry.iterator).y);
      }
    }

    return new Point(width, height);
  }

  public Point minimumSize() {
    return new Point(minimumSize.x, minimumSize.y);
  }

  public Point preferredSize() {
    return new Point(preferredSize.x, preferredSize.y);
  }

  private int[] computeAdjustedColumnSizes(int width) {
    // Remove column spacing from equation first off
    width = width - spacing.x * (columns.length - 1);

    int minimumWidth = 0;
    int preferredWidth = 0;
    for (int i = 0; i < columns.length; i++) {
      minimumWidth += minimumColSizes[i];
      preferredWidth += preferredColSizes[i];
    }

    // Case 1: width < minimum width
    // Start with minimum column sizes.  Set each column to
    // minimum column size * width / minimum width.
    if (width < minimumWidth) {
      int[] colSizes = new int[minimumColSizes.length];
      for (int i = 0; i < colSizes.length; i++) {
        colSizes[i] = minimumColSizes[i] * width / minimumWidth;

        // adjust width and minimum width - eliminates round-off error 
        width -= colSizes[i];
        minimumWidth -= minimumColSizes[i];
      }

      return colSizes;
    }

    // Case 2: minimum width = width
    // Use minimum column sizes.
    if (width == minimumWidth)
      return minimumColSizes;

    // Case 3: minimum width < width < preferred width
    // Start with minimum column sizes.  Expand the columns proportionate to
    // the difference between minimum and preferred column sizes.
    if (width < preferredWidth) {
      int extraWidth = width - minimumWidth;
      int widthDifference = preferredWidth - minimumWidth;

      int[] colSizes = new int[columns.length];
      for (int i = 0; i < columns.length; i++) {
        int colDifference = preferredColSizes[i] - minimumColSizes[i];

        int addedWidth = (widthDifference > 0) ?
            extraWidth * colDifference / widthDifference : 0;

        colSizes[i] = minimumColSizes[i] + addedWidth;

        // adjust extraWidth and widthDifference - eliminates round-off error
        extraWidth -= addedWidth;
        widthDifference -= colDifference;
      }

      return colSizes;
    }

    // Case 4: preferred width = width
    // Use preferred column sizes.
    if (preferredWidth == width)
      return preferredColSizes;

    // Case 5: preferred width < width
    // Start with preferred column sizes.  Expand the columns with the grow
    // option set, distributing extra space according to weight.
    if (preferredWidth < width) {
      int extraWidth = width - preferredWidth;
      int weight = 0;

      // Find the weighted columns.
      List<Integer> weightedCols = new ArrayList<Integer>();
      for (int i = 0; i < columns.length; i++)
        if (columns[i].weight > 0) {
          weight += columns[i].weight;
          weightedCols.add(i);
        }

      // Start with preferred column sizes. 
      int[] colSizes = preferredColSizes.clone();
      // Expand weighted columns according to their weights.
      for (int i : weightedCols) {
        int colWeight = columns[i].weight;

        int addWidth = colWeight * extraWidth / weight;

        colSizes[i] += addWidth;

        // adjust extraWidth and growColumns - eliminates round-off error
        extraWidth -= addWidth;
        weight -= colWeight;
      }

      return colSizes;
    }

    throw new RuntimeException("GridPrintIterator.adjustColumnSizes(...) logic is flawed.");
  }

  public boolean hasNext() {
    return row < rows.size();
  }

  public PrintPiece next(int width, int height) {
    if (!hasNext())
      throw new IllegalStateException();

    // Compute column sizes for the available width.
    int[] colSizes = computeAdjustedColumnSizes(width); 

    List<CompositeEntry> pieces =
      new ArrayList<CompositeEntry>();

    boolean done = false;
    int y = 0;

    while (!done) {
      boolean rowDone = true;

      List<GridEntry> rowEntries = rows.get(row);
      int x = 0;
      int col = 0;
      int rowHeight = 0;
      for (int i = 0; i < rowEntries.size(); i++) {
        GridEntry entry = rowEntries.get(i);
        PrintIterator iter = rowEntries.get(i).iterator;

        // Determine width of the cell span.
        int cellspanWidth = (entry.colspan - 1) * spacing.x;
        for (int j = col; j < col + entry.colspan; j++)
          cellspanWidth += colSizes[j];

        // Skip if this entry has no more pieces.
        if (!iter.hasNext()) {
          // But advance the column cursor
          x = x + cellspanWidth + spacing.x;
          col += entry.colspan;
          continue;
        }

        PrintPiece piece = iter.next(cellspanWidth, height - y);

        if (piece == null) {
          // Something didn't fit - another pass will be needed on this row.
          rowDone = false;
        } else {
          // Find the alignment.
          int align = entry.align;
          if (align == SWT.DEFAULT)
            align = columns[col].align;

          // Calculate X offset within the cellspan according to alignment
          int offset = 0;
          if (align == SWT.CENTER)
            offset = (cellspanWidth - piece.getSize().x) / 2;
          else if (align == SWT.RIGHT)
            offset = cellspanWidth - piece.getSize().x;

          pieces.add(new CompositeEntry(
              piece, new Point(x+offset, y)));
          rowHeight = Math.max(rowHeight, piece.getSize().y);

          // Does this column have any more pieces?
          if (iter.hasNext())
            rowDone = false;
        }

        x = x + cellspanWidth + spacing.x;
        col += entry.colspan;
      }

      y += rowHeight + spacing.y;

      if (rowDone) {
        // We finished the row, advance to the next row
        row++;
        // Done if we just finished the last row
        done = !hasNext();
      } else {
        // Couldn't finish the row, so we've fit
        // everything we can on this page.
        done = true;
      }
    }

    if (pieces.size() == 0)
      return null;
    else {
      Point size = new Point((colSizes.length - 1) * spacing.x, 0);
      for (int col : colSizes)
        size.x += col;
      return new CompositePiece(pieces, size);
    }
  }

  public PrintIterator createClone() {
    return new GridIterator(this);
  }
}